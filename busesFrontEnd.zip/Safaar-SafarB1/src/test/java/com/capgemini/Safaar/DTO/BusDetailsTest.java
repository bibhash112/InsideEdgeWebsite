package com.capgemini.Safaar.DTO;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class BusDetailsTest {

	BusDetails busService=new BusDetails();
	
	@Test
	public void getSetSourceTest()
	{
		busService.setSource("Kolkata");
	    assertEquals("Kolkata", busService.getSource());
	}
	 @Test
	 public void getSetDestinationTest()
	 {
		 busService.setDestination("Siliguri");
		 assertEquals("Siliguri", busService.getDestination());
	 }
	 @Test
	 public void getSetDepartureDateTest()
	 {
		 busService.setDepartureDate("20181010");
		 assertEquals("20181010", busService.getDepartureDate());
	 }
	 @Test
	 public void getSetDepartureTimeTest()
	 {
		 busService.setDepartureTime("10:00");
		 assertEquals("10:00", busService.getDepartureTime());
	 }
	 @Test
	 public void getSetDurationTest()
	 {
		 busService.setDuration("10");
		 assertEquals("10", busService.getDuration());
	 }
	 @Test
	 public void getSetBusTypeTest()
	 {
		 busService.setBusType("Volvo");
		 assertEquals("Volvo", busService.getBusType());
	 }
	 @Test
	 public void getSetTravelsName()
	 {
		 busService.setTravelsName("one");
		 assertEquals("one", busService.getTravelsName());
	 }
	 @Test
	 public void getSetRating()
	 {
		 busService.setRating("4.0");;
		 assertEquals("4.0", busService.getRating());
	 }
	 @Test
	 public void getSetFare()
	 {
		 busService.setFare("1400");
		 assertEquals("1400", busService.getFare());
	 }
	 
	 @Test
	 public void parameterisedConstructorTest()
	 {
		 BusDetails testBus=new BusDetails("a","b","c","d","e","f","g","h","i");
		 assertEquals(busService.getClass(), testBus.getClass());
		 
	 }

	 
}
