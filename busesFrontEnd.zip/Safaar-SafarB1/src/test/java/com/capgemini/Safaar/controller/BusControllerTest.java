package com.capgemini.Safaar.controller;

/*import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.codehaus.jettison.json.JSONException;
import org.junit.Test;
import org.mockito.exceptions.base.MockitoException;

import com.capgemini.Safaar.DTO.BusDetails;*/

public class BusControllerTest {
	
/*	BusController testBusController =mock(BusController.class);
	BusDetails busDetails=mock(BusDetails.class);
	@Test(expected =MockitoException.class)
	public void homeExceptionTest() throws org.json.JSONException
	{
		when(testBusController.home()).thenThrow(new JSONException("null"));
	}
	@Test
	public void homeTest() throws org.json.JSONException
	{
		when(testBusController.home()).thenCallRealMethod();
	}*/

}
