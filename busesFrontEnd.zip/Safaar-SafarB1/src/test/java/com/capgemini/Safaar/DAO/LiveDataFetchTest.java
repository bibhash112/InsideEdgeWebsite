package com.capgemini.Safaar.DAO;


import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.BufferedReader;
import java.io.IOException;

import org.junit.Test;

public class LiveDataFetchTest {
	BufferedReader rd=mock(BufferedReader.class);
	
	
	@Test
	public void readAllTest() throws IOException
	{
		when(LiveDataFetch.readAll(rd))
		.thenReturn("stringReturned");
		assertEquals("stringReturned",LiveDataFetch.readAll(rd));
	}
}
