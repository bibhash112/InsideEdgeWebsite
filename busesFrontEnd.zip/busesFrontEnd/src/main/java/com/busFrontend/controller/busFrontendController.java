package com.busFrontend.controller;


import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import com.busFrontend.DTO.BusDetails;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;



@RestController
public class busFrontendController {
	
	@RequestMapping(value="/home", method=RequestMethod.GET)
	public ModelAndView homePage()
	{
		return new ModelAndView("index");
	}
	
	@RequestMapping(value="/index", method=RequestMethod.GET)
	public ModelAndView listOfBuses(
			@RequestParam(value="source") String source,
            @RequestParam(value="destination") String destination,
            @RequestParam(value="dateOfJourney") String dateOfJourney
            ){
	final String uri = "http://localhost:8066/home?source="+source+"&destination="+destination+"&dateOfJourney="+dateOfJourney+"";
	RestTemplate restTemplate = new RestTemplate();
	@SuppressWarnings("unchecked")
	ArrayList<BusDetails> list=restTemplate.getForObject(uri, ArrayList.class);
	ObjectMapper mapper = new ObjectMapper();
	List<BusDetails> busList = mapper.convertValue(list, new TypeReference<List<BusDetails>>() { });
	ModelAndView view=new ModelAndView();
	view.addObject("buses",busList);
    view.setViewName("busSearch");
    return view;
	}

}
